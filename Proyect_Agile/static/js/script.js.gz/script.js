const navbar = document.getElementById('navbar');
const right = document.getElementById('right-screen');
    console.log('hola')

setTimeout(function (){
    $('.alert-block').fadeOut('slow')
}, 3000)